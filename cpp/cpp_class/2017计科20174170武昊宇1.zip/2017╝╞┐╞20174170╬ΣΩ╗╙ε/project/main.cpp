/*
 * main.cpp
 *
 *  Created on: 2018-4-9
 *      Author: administrator
 */
#include "Message.h"

int main()
{
	Message().run_Message();
	return 0;
}



