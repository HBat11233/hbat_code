#include <iostream>
#define c(a,b) (60-9*a-4*b)
#define d(a,b,c) (40-a-b-c)

using namespace std;

int main()
{
    for(int a=1;a<7;++a)
        for(int b=1;b<16;++b)
            if(c(a,b)>=1&&d(a,b,c(a,b))>=1)
                printf("10Ԫ%d�ţ�5Ԫ%d�ţ�2Ԫ%d�ţ�1Ԫ%d��\n",a,b,c(a,b),d(a,b,c(a,b)));
    system("pause");
    return 0;
}
