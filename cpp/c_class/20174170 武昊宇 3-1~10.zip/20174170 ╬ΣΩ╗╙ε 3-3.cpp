#include <iostream>

using namespace std;

class TG
{
public :
	TG(int n);
	int print();
private :
	int _num;
	bool _bo;
};

TG::TG(int n)
		:_num{n},_bo{false}
	{
		int i=0;
		int temp =1;
		while(n>0)
		{
			i++;
			n/=10;
		}
		for(int j=0;j<i;++j)
		{
			temp*=10;
		}
		if(_num==_num*_num%temp)_bo=true;
	}
	
int TG::print()
{
	if(_bo)cout<<_num<<' ';
	return 0;
}

int main()
{
	for(int i=1;i<100;++i)
	{
		TG num={i};
		num.print();
	}
	system("pause");
	return 0;
} 
