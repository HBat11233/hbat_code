#include<stdio.h>
#include <stdlib.h>
#include<math.h>
int main()
{
	int x; 
    int pownum[10];
    printf("����n�����������������");
	scanf("%d",&x);
	int l=pow(10,x-1),r=pow(10,x),i,i0,j,t,a;
	for(int i=0;i<10;++i)
	{
			pownum[i]=pow(i,x);
	}
	    for(i=l; i<r; i++)
	    {
			i0 = i;
			t=i0;//这里
	        for(j=0;j<x;j++)
	        {
	            a = i0%10;
				t -=pownum[a];//这里
	            i0 /= 10;
	        }
        if(t==0) printf("%d\n",i);
		}
	system("pause");
	return 0;
}
