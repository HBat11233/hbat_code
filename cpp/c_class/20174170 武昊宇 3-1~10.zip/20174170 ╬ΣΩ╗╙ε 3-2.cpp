#include <iostream>
#include <cstdio>

using namespace std;

int main()
{
    double e=1;
    int m=1,n=1;
    double olde=0;
    while(e-olde>1e-6)
    {
        olde=e;
        m*=n;
        n++;
        e+=1.0/m;
    }
    printf("%.6lf\n",e);
    system("pause");
    return 0;
}