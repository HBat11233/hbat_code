﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 天地银行
{
    public class Account
    {
        double money;   //金额
        string id;      //账号
        string pwd;     //密码
        //string name;

        public Account(string id, string pwd, double money)
        {
            //if( money < 0 ) throw new Exception("....");
            this.id = id;
            this.pwd = pwd;
            this.money = money;
        }

        public double getMoney()
        {
            return money;
        }

        public void setMoney(double val)
        {
            this.money = val;
        }

        public string getId()
        {
            return id;
        }

        public void setId(string id)
        {
            this.id = id;
        }

        public string getpwd()
        {
            return pwd;
        }

        public void setPwd(string pwd)
        {
            this.pwd = pwd;
        }

        public bool SaveMoney(double money)
        {
            string tstr = (money * 100).ToString();
            int temp = int.Parse(tstr);
            double tempdo = temp / 100.0;
            if (money < 0||money-tempdo!=0.0) return false;  //判断是否合法
            this.money += money;
            return true;
        }

        public bool WithdrawMoney(double money)     //取钱
        {
            double tstr = (money * 100);
            int temp = (int)tstr;
            double tempdo = temp / 100.0;
            if (money < 0 || money - tempdo != 0.0) return false;  //判断是否合法
            if (this.money >= money)
            {
                this.money -= money;
                return true;
            }

            return false;

        }

        public bool IsMatch(string id, string pwd)//判断密码是否正确
        {
            return id == this.id && pwd == this.pwd;
        }
    }
}
