﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 天地银行
{
    class Scanner
    {
        static public void Show(string msg)
        {
            Console.WriteLine(msg);
        }
        static public string GetInput()            //输入一行
        {
            return Console.ReadLine();// 输入字符
        }
    }
}
