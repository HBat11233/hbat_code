﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 天地银行
{
    public class ATM
    {
        Bank bank;              //某个银行的atm
        public ATM(Bank bank)
        {
            this.bank = bank;
        }

        public void Transaction()//atm的运行界面
        {
            Scanner.Show("please insert your card");
            string id = Scanner.GetInput();

            Scanner.Show("please enter your password");
            string pwd = Scanner.GetInput();

            Account account = bank.FindAccount(id, pwd);

            if (account == null)
            {
                Scanner.Show("card invalid or password not corrent");
                return;
            }

            Scanner.Show("1: display; 2: save; 3: withdraw; 4: out");
            for (string op = Scanner.GetInput(); op != "4"; op = Scanner.GetInput())
            {
                if (op == "1")
                {
                    Scanner.Show("balance: " + account.getMoney());
                }
                else if (op == "2")
                {
                    Scanner.Show("save money");
                    string smoney = Scanner.GetInput();
                    double money = double.Parse(smoney);

                    bool ok = account.SaveMoney(money);
                    if (ok) Scanner.Show("ok");
                    else Scanner.Show("errer");

                    Scanner.Show("balance: " + account.getMoney());
                }
                else if (op == "3")
                {
                    Scanner.Show("withdraw money");
                    string smoney = Scanner.GetInput();
                    double money = double.Parse(smoney);

                    bool ok = account.WithdrawMoney(money);
                    if (ok) Scanner.Show("ok");
                    else Scanner.Show("errer");

                    Scanner.Show("balance: " + account.getMoney());

                }
                Scanner.Show("1: display; 2: save; 3: withdraw");
            }
        }
    }
}
