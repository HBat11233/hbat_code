﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 天地银行
{
    public class Bank
    {
        List<Account> accounts = new List<Account>();

        public Account OpenAccount(string id, string pwd, double money)//注册账号
        {
            if (this.FindAccount(id, pwd) != null)
            {
                Scanner.Show("repeat!");
                return null;
            }
            Account account = new Account(id, pwd, money);              //注册
            accounts.Add(account);                                      //添加到银行

            return account;
        }

        public bool CloseAccount(Account account)                       //从银行删除
        {
            int idx = accounts.IndexOf(account);
            if (idx < 0) return false;
            accounts.Remove(account);
            return true;
        }

        public Account FindAccount(string id, string pwd)               //查找账户
        {
            foreach (Account account in accounts)
            {
                if (account.IsMatch(id, pwd))                           //账号密码都正确
                {
                    return account;
                }
            }

            return null;
        }
    }
}
