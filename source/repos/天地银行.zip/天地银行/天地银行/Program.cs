﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 天地银行
{
    class Program
    {
        static void Main(string[] args)
        {
            Bank bank = new Bank();
            while (true)
            {
                Scanner.Show("1:new account; 2:login;");
                string tmp;
                for (tmp = Scanner.GetInput(); tmp != "1" && tmp != "2"; tmp = Scanner.GetInput())
                    Scanner.Show("1:new account; 2:login;");
                switch (tmp)
                {
                    case "1":
                        Scanner.Show("Account:");
                        string temp1 = Scanner.GetInput();
                        Scanner.Show("Password:");
                        string temp2 = Scanner.GetInput();
                        Scanner.Show("Money:");
                        double temp3;
                        do
                        {
                            temp3 = Double.Parse(Scanner.GetInput());
                            if (temp3 < 0 || temp3 * 100 - (int)(temp3 * 100) > 0) Scanner.Show("errer");
                        } while (temp3 < 0 || temp3 * 100 - (int)(temp3 * 100) > 0);
                        bank.OpenAccount(temp1, temp2, temp3);
                        break;
                }
                ATM atm = new ATM(bank);
                atm.Transaction();
            }
        }
    }
}
